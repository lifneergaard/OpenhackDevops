﻿using System;
namespace MyDriving.UITests
{
	public class LoginTests
	{
		public LoginTests()
		{
		}

		// Simulate Login w/ Facebook
		// Simulate Login w/ Twitter
		// Simulate Login w/ MS
		// Simulate Login w/ Skip Auth
		// Simulate no connectivity login attempt
	}
}

