﻿using System;
namespace MyDriving.UITests
{
	public class PastTripTests
	{
		// Navigate to past trip
		// Move scrubber
			// Car updated
		// Pull to refresh works
	}
}

